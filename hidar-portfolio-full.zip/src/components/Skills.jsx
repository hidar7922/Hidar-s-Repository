import React from "react";
export default function Skills() {
  return (
    <section style={{ marginTop: 18 }}>
      <h3 style={{ marginBottom: 10, fontSize: 18, fontWeight: 700 }}>Skills</h3>
      <div className="grid-3">
        <div className="card">
          <h4 style={{ fontWeight: 700 }}>Programming & Data</h4>
          <ul style={{ marginTop: 8, color: "#334155" }}>
            <li>Python — EDA, ML, NLP</li>
            <li>SQL — Data extraction & joins</li>
            <li>Power BI & Tableau — Dashboards</li>
          </ul>
        </div>
        <div className="card">
          <h4 style={{ fontWeight: 700 }}>Frontend</h4>
          <ul style={{ marginTop: 8, color: "#334155" }}>
            <li>HTML, CSS, JavaScript</li>
            <li>React — component-driven UI</li>
            <li>Framer Motion — UI animations</li>
          </ul>
        </div>
        <div className="card">
          <h4 style={{ fontWeight: 700 }}>Tools & Deployment</h4>
          <ul style={{ marginTop: 8, color: "#334155" }}>
            <li>Flask / Streamlit — Model deployment</li>
            <li>Git / GitHub — Version control</li>
            <li>Docker (familiar)</li>
          </ul>
        </div>
      </div>
    </section>
  );
}