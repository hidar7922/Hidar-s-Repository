import React from "react";
export default function About() {
  return (
    <section className="card" style={{ marginTop: 18 }}>
      <h2 style={{ fontSize: 20, fontWeight: 700 }}>About Me</h2>
      <p style={{ marginTop: 8, color: "#334155" }}>
        Data Analyst & Frontend Developer with experience in data analytics, machine learning, and web development. Skilled in extracting insights, building predictive models, and creating interactive web applications. Passionate about leveraging data and technology to solve business problems and enhance user experiences.
      </p>
    </section>
  );
}