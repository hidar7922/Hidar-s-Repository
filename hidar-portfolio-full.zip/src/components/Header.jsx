import React, { useRef, useEffect } from "react";
import { motion } from "framer-motion";
import * as THREE from "three";

export default function Header() {
  const canvasRef = useRef(null);
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const renderer = new THREE.WebGLRenderer({ canvas, alpha: true, antialias: true });
    const w = canvas.clientWidth || 400;
    const h = 220;
    renderer.setSize(w, h);
    renderer.setPixelRatio(window.devicePixelRatio || 1);
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(50, w / h, 0.1, 1000);
    camera.position.z = 4;
    const light = new THREE.DirectionalLight(0xffffff, 1);
    light.position.set(5, 5, 5);
    scene.add(light);
    const geom = new THREE.TorusKnotGeometry(0.9, 0.25, 120, 32);
    const mat = new THREE.MeshStandardMaterial({ metalness: 0.3, roughness: 0.3 });
    const mesh = new THREE.Mesh(geom, mat);
    scene.add(mesh);
    let id;
    const animate = () => {
      mesh.rotation.x += 0.005;
      mesh.rotation.y += 0.007;
      renderer.render(scene, camera);
      id = requestAnimationFrame(animate);
    };
    animate();
    return () => {
      cancelAnimationFrame(id);
      renderer.dispose();
    };
  }, []);
  return (
    <header className="header-grid">
      <div style={{ flex: 1 }}>
        <motion.h1 initial={{ y: -10, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ duration: 0.5 }} style={{ fontSize: 32, fontWeight: 800 }}>
          Hidar Ali
        </motion.h1>
        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.1 }} style={{ marginTop: 8, color: "#475569" }}>
          Data Scientist • Data Analyst • Frontend Developer
        </motion.p>
        <div style={{ marginTop: 12, display: "flex", gap: 10 }}>
          <a className="btn" href="/Final_Resume.pdf" download>
            Download Resume
          </a>
          <a className="btn" href="#contact" style={{ background: "#e9d5ff", color: "#4f46e5" }}>
            Contact Me
          </a>
        </div>
        <div style={{ marginTop: 12, color: "#6b7280" }}>
          <a className="small-link" href="mailto:hedar7922@gmail.com">hedar7922@gmail.com</a> •{" "}
          <a className="small-link" href="https://github.com/hidar7922">GitHub</a> •{" "}
          <a className="small-link" href="https://www.linkedin.com/in/hidar-ali-45b73b175/">LinkedIn</a>
        </div>
      </div>
      <div style={{ width: 360 }} className="card">
        <canvas ref={canvasRef} style={{ width: "100%", height: 220 }} />
      </div>
    </header>
  );
}