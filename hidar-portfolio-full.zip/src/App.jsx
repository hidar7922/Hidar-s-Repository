import React from "react";
import Header from "./components/Header";
import About from "./components/About";
import Skills from "./components/Skills";
import Experience from "./components/Experience";
import Projects from "./components/Projects";
import Education from "./components/Education";
import Contact from "./components/Contact";

export default function App() {
  return (
    <div>
      <div className="container">
        <Header />
        <main style={{ marginTop: 24 }}>
          <About />
          <Skills />
          <Experience />
          <Projects />
          <Education />
          <Contact />
        </main>
        <footer>
          <p>© {new Date().getFullYear()} Hidar Ali — Data Scientist</p>
        </footer>
      </div>
    </div>
  );
}